﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GnomeTest
{
    [TestClass]
    public class SecondGnome
    {
        [TestMethod]
        public void Somebody()
        {
            //arrange
            int i;
            int n = 0;
            int l = 14;
            int[] a = { 7, 12, 9, 1, 3, 14, 5, 13, 8, 10, 4, 2, 6, 11 };
            int[] c = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14 };
            int[] b = new int[l];

            //act
            MyGnomeConsole.Program gnome = new MyGnomeConsole.Program();
            b = gnome.GnomeSort(a, l);

            //assert
            for (i = 0; i < l; i++)           //check
            {
                if (c[i] == b[i]) n++;
            }
            Assert.AreEqual(l, n);
        }
    }
}
