﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GnomeTest
{
    [TestClass]
    public class FirstGnome
    {
        [TestMethod]
        public void Someone()
        {
            //arrange
            int i;
            int n = 0;
            int l = 9;
            int[] a = { 5, 8, 1, 4, 6, 9, 7, 3, 2 };
            int[] c = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            int[] b = new int[l];

            //act
            MyGnomeConsole.Program gnome = new MyGnomeConsole.Program();
            b = gnome.GnomeSort(a, l);

            //assert
            for (i = 0; i < l; i++)           //check
            {
                if (c[i] == b[i]) n++;
            }
            Assert.AreEqual(l, n);
        }
    }
}
