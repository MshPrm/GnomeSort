﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyGnomeConsole
{
    public class Program
    {
        public static void Main(string[] args)
        {
            int i;
            int dl = 6;                                    //length
            int[] arr = new int[dl];
            arr[0] = 15; arr[1] = 25; arr[2] = 14; arr[3] = 9; arr[4] = 14; arr[5] = -15;
            Console.WriteLine("Start gnome!");
            Console.WriteLine("Length of array: "+ dl);
            Console.Write("Array: ");
            for (i = 0; i < dl; i++)                       //output array
            {
                Console.Write(arr[i] + " ");
            }
            Console.WriteLine();
            Console.WriteLine("Work...");
            MyGnomeConsole.Program gnome = new MyGnomeConsole.Program();
            arr = gnome.GnomeSort(arr, dl);
            Console.Write("Array: ");
            for (i = 0; i < dl; i++)                       //output array
            {
                Console.Write(arr[i]+" ");
            }
            Console.WriteLine();
            Console.ReadKey();
        }

        public int[] GnomeSort(int[] a, int l)              //sorting
        {
            int i = 1;
            int s;
            while (i < l)
            {
                if (i == 0) i++;
                if (a[i - 1] <= a[i]) ++i;
                else
                {
                    s = a[i];
                    a[i] = a[i - 1];
                    a[i - 1] = s;
                    --i;
                }
            }
            return a;                                     //result
            throw new NotImplementedException();
        }
    }
}